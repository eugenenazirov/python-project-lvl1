from brain_games.even_engine import *


def main():
    run_game()


if __name__ == '__main__':
    main()