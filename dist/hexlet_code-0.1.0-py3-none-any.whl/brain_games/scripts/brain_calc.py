#!/usr/bin/env python

from brain_games.games.calc_engine import calc_game


def main():
    calc_game()


if __name__ == '__main__':
    main()