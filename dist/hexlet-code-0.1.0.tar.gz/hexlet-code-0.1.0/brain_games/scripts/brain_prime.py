#!/usr/bin/env python

from brain_games.games.prime_engine import prime_game


def main():
    prime_game()


if __name__ == '__main__':
    main()
