### Hexlet tests and linter status:
[![Actions Status](https://github.com/eugenenazirov/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/eugenenazirov/python-project-lvl1/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/a99a88d28ad37a79dbf6/maintainability)](https://codeclimate.com/github/codeclimate/codeclimate/maintainability)

Games demo:
"Even or Not":
https://asciinema.org/a/502931