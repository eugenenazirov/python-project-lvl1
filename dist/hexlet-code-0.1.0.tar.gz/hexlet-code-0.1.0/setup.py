# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'The first study project on Hexlet Python course.',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/eugenenazirov/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/eugenenazirov/python-project-lvl1/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/a99a88d28ad37a79dbf6/maintainability)](https://codeclimate.com/github/codeclimate/codeclimate/maintainability)\n\nWelcome, to The Brain Games, the Hexlet Course first project!\nThere are five simple mind games that you can run in your Terminal.\n\nRequirements:\nOS: Linux, Windows 10 (WSL), MacOS\nPython 3.10\n\n\nGames demo:\n1. "Even or Not":\nhttps://asciinema.org/a/502931\n\n2. "Calculator":\nhttps://asciinema.org/a/503019\n\n3. "Find Great Common Divisor":\nhttps://asciinema.org/a/503546\n\n4. "Arithmetic Progression":\nhttps://asciinema.org/a/503663\n\n5. "Is the Number Prime?":\nhttps://asciinema.org/a/503668\n',
    'author': 'Eugene Nazirov',
    'author_email': 'jagzonmusic@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
